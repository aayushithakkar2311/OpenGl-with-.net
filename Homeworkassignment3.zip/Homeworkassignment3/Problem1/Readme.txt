	press'a','A'to move drawing right-side

	press'd','D' to move drawing left-side
 
	press'w','W' to move drawing forward 

	press's','S' to move drawing backward
	
	press'q','Q' to rotate the drawing 360*

	press'e','E' to rotate the drawing
 		