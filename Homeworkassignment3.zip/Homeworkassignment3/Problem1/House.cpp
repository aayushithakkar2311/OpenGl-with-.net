/*

   Computer graphics Homework assignment3

			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <GL\glew.h>
#include <GL\freeglut.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdlib.h>

GLfloat xRotated, yRotated, zRotated;
GLdouble radius = 0.5;

void setMaterial(GLfloat ambientR, GLfloat ambientG, GLfloat ambientB,
	GLfloat diffuseR, GLfloat diffuseG, GLfloat diffuseB,
	GLfloat specularR, GLfloat specularG, GLfloat specularB,
	GLfloat shininess) {

	GLfloat ambient[] = { ambientR, ambientG, ambientB };
	GLfloat diffuse[] = { diffuseR, diffuseG, diffuseB };
	GLfloat specular[] = { specularR, specularG, specularB };

	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specular);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, shininess);
}

void Cylinder(float trunkRadius, float trunkHeight) {

	GLUquadric* obj = gluNewQuadric();

	// draw tree part
	glPushMatrix();

	glRotatef(-90, 1.0, 0.0, 0.0); // always necessary since cylinder is drawn along z-axis
	gluCylinder(obj, trunkRadius, trunkRadius / 2.0, trunkHeight, 20, 20);
	glPopMatrix();
}

void Tree(float A, float C)
{
	float B = 0.3; 
	float inner= 0.10;
	float outer= 0.15;
	setMaterial(0, 0.1, 0, 0, 0.1, 0, 0, 0.1, 0, 1);
	for (int i = 0; i < 3; i++) {
		glPushMatrix();
		glTranslatef(A, B, C);
		glRotatef(-90, 1, 0, 0);
		glutSolidTorus(inner, outer, 20, 20);
		glPopMatrix();
		B = B + 0.1;
		inner = inner / 1.5;
		outer = outer / 1.5;
	}
	setMaterial(0.2, 0.2, 0, 0.2, 0.2, 0, 0.2, 0.2, 0, 1);
	glPushMatrix();
	glTranslatef(A, 0, C);
	Cylinder(0.15, 0.2);
	glPopMatrix();
}
void sun()
{
	xRotated = yRotated = zRotated = 30.0;
	xRotated = 43;
	yRotated = 50;
	xRotated += 0.01;
	zRotated += 0.01;
	glPushMatrix();
	glTranslatef(-0.9, 1.2, -5.0);
	setMaterial(1.0, 0.5, 0.0, 1.0, 0.5, 0.0, 1.0, 1.0, 1.0, 10);
	// changing in transformation matrix.
	// rotation about X axis
	glRotatef(xRotated, 1.0, 0.0, 0.0);
	// rotation about Y axis
	glRotatef(yRotated, 0.0, 1.0, 0.0);
	// rotation about Z axis
	glRotatef(zRotated, 0.0, 0.0, 1.0);
	// scaling transfomation 
	glScalef(1.0, 1.0, 1.0);
	// built-in (glut library) function , draw you a sphere.
	glutSolidSphere(radius, 20, 20);
	glPopMatrix();
}
void cloud1()
{
	glPushMatrix();
	glTranslatef(-1.9, 1.5, -2.0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.7, -2.0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.5, -2.0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();
	  
	glPushMatrix();
	glTranslatef(-1.9, 1.7, -2.0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();

}
void cloud2()
{
	glPushMatrix();
	glTranslatef(-1.9, 1.7, 0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.9, 0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.7, 0);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();

}
void cloud3()
{
	glPushMatrix();
	glTranslatef(-1.9, 1.7, 1.7);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.9, 1.7);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();


	glPushMatrix();
	glTranslatef(-1.6, 1.7, 1.7);
	setMaterial(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 50);
	glScalef(1.0, 1.0, 1.0);
	glutSolidSphere(.3, 20, 20);
	glPopMatrix();

}
void display() {

	/* clear window */
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/* future matrix manipulations should affect the modelview matrix */
	glMatrixMode(GL_MODELVIEW);

	//	/* draw scene */
	glPushMatrix();
	
	sun();
	cloud1();
	cloud2();
	cloud3();
	//ground
	glPushMatrix();
	setMaterial(0, 0.1, 0, 0, 0.1, 0, 0, 0.1, 0, 1);
	glTranslatef(0, -1.5, 0.0);
	glScalef(25, 0.25, 25);
	glutSolidCube(0.25);
	glPopMatrix();

	//tree
	glPushMatrix();
	glScalef(1.2, 1.8, 1.2);
	Tree(2.0, -0.5);
	glPopMatrix();


	//tree
	glPushMatrix();
	glScalef(1.2, 1.8, 1.2);
	Tree(1.3, -0.8);
	glPopMatrix();

	//tree
	glPushMatrix();
	Tree(3, 0.1);
	glPopMatrix();

	//tree
	glPushMatrix();
	glScalef(1, 1.8, 1.2);
	Tree(2.5, 1);
	glPopMatrix();

	//tree
	glPushMatrix();
	Tree(3, 1);
	glPopMatrix();

	//tree
	glPushMatrix();
	Tree(1.9, 3.2);
	glPopMatrix();

	//tree
	glPushMatrix();
	glScalef(1, 1.8, 1.2);
	Tree(1, 2.8);
	glPopMatrix();


	//tree
	glPushMatrix();
	Tree(-0.8, 1.5);
	glPopMatrix();

	//road

	//white cube
	glPushMatrix();
	setMaterial(1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
	glTranslatef(-0.3, -1, 1.8);
	glScalef(50, 0, 2);
	glutSolidCube(0.10);
	glPopMatrix();

	//black cube
	glPushMatrix();
	setMaterial(0, 0, 0, 0, 0, 0, 0, 0, 0, 1);
	glTranslatef(0.2, -1.30, 1.7);
	glScalef(17.5, 0.5, 5);
	glutSolidCube(0.35);
	glPopMatrix();
	
	// house
	glPushMatrix();
	setMaterial(0.5, 0, 0, 0.5, 0,0, 0.5, 0, 0, 1);
	glutSolidCube(2);                 // building

	glTranslatef(0, 1, 0);
	glPushMatrix();                   // roof
	glRotatef(-90, 1, 0, 0);
	setMaterial(1.0, 0.5, 0.0, 1.0, 0.5, 0.0, 1.0, 1.0, 1.0, 10);
	glutSolidCone(1.5, 1, 16, 8);
	glPopMatrix();

	glTranslatef(.75, .5, -.75);
	glPushMatrix();                   // chimney
	glScalef(1, 3, 1);
	setMaterial(0.5, 0.0, 0.0, 0.5, 0.0, 0.0, 0.5, 0.0, 0.0, 1);
	glutSolidCube(.25);
	glPopMatrix();
	glPopMatrix();

	glTranslatef(0, -.65, 2);


	////door 
	//glPushMatrix();
	//setMaterial(1.0, 0.5, 0.0, 1.0, 0.5, 0.0, 1.0, 1.0, 1.0, 10);
	//glTranslatef(1.8, 1.8, 0);
	//glScalef(2, 4, 0.25);
	//glutSolidCube(0.25);
	//glPopMatrix();

	// car
	setMaterial(0.5, 0.0, 1.0, 0.5, 0.0, 1, 0.5, 0.0, 1, 10);
	glPushMatrix();

	glPushMatrix();                   // body
	glScalef(2, .5, 1);
	glutSolidCube(.5);
	glPopMatrix();
	glTranslatef(0, 0, .25);
	glPushMatrix();
	glTranslatef(-.4, -.2, 0);
	glutSolidTorus(.05, .1, 8, 8);       // wheel
	glTranslatef(.8, 0, 0);
	glutSolidTorus(.05, .1, 8, 8);       // wheel
	glPopMatrix();
	glTranslatef(0, 0, -.5);
	glPushMatrix();
	glTranslatef(-.4, -.2, 0);
	glutSolidTorus(.05, .1, 8, 8);       // wheel
	glTranslatef(.8, 0, 0);
	glutSolidTorus(.05, .1, 8, 8);       // wheel
	glPopMatrix();
	
	glPopMatrix();

	glPopMatrix();

	/* flush drawing routines to the window */
	glFlush();
}

void reshape(int width, int height) {

	/* define the viewport transformation */
	
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'a'://right side
	case 'A':
		glTranslatef(1.0, 0.0, 0.0);
		break;
	case 'd'://left side
	case 'D':
		glTranslatef(-1.0, 0.0, 0.0);
		break;
	case 'w'://forward
	case 'W':
		glTranslatef(0.0, 0.0, 1.0);
		break;
	case 's':
	case 'S'://backward
		glTranslatef(0.0, 0.0, -1.0);
		break;
	case 'q':
	case 'Q'://rotate 360*
		glRotatef(-1.9, 1.0, 0.0, 0.0);

	case 'e':
	case 'E'://rotate
		glRotatef(1.9, 0.0, 1.0, 0.0);
	}
	display();
}

void resize(int width, int height)
{
	glViewport(0, 0, width, height);

}


int main(int argc, char * argv[]) {

	/* initialize GLUT, using any commandline parameters passed to the
	   program */
	glutInit(&argc, argv);

	/* setup the size, position, and display mode for new windows */
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(0, 0);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH);

	//	/* create and set up a window */
	glutCreateWindow("house2");
	glClearColor(0, 1, .8, 0.0);
	glutDisplayFunc(display);
	glutReshapeFunc(resize);
	glutKeyboardFunc(keyboard);
	/* set up depth-buffering */
	glEnable(GL_DEPTH_TEST);

	/* set up lights */
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	GLfloat lightpos[] = { 0.0, 15.0, 15.0 };
	GLfloat lightcolor[] = { 0.5, 0.5, 0.5 };
	GLfloat ambcolor[] = { 0.2, 0.2, 0.0 };

	glEnable(GL_LIGHTING);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambcolor);

	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightcolor);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightcolor);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightcolor);

	/* define the projection transformation */
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40, 1, 4, 20);

	/* define the viewing transformation */
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(5.0, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

	/* tell GLUT to wait for events */
	glutMainLoop();
}
