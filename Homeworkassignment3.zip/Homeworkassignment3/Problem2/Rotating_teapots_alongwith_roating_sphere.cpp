/*

   Computer graphics Homework assignment1

			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <GL\glew.h>
#include <GL\freeglut.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdlib.h>

GLuint teapotList;
GLuint sphereList;
GLdouble size = 0.09;
GLdouble radius = 2;
GLfloat emitLight[] = { 0.9, 0.9, 0.9, 0.01 };
GLfloat Noemit[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat qaLightPosition[] = { 0, 0, 0, 1 };// Positional Light
GLfloat qaLightDirection[] = { 1, 1, 1, 1 };// Directional Light
void init(void)
{

	GLfloat mat_ambient1[] = { 0.5f, 0.5f, 0.6f, 1.0f };
	GLfloat mat_diffuse1[] = { 0.6f, 0.6f, 0.6f, 1.0f };
	GLfloat mat_specular1[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat mat_shininess1[] = { 100.0f };
	GLfloat position[] = { 0.0, 1.0, 3.0, 0.0 };
	GLfloat lmodel_ambient[] = { 0.5, 0.2, 0.2, 2.0 };
	GLfloat local_view[] = { 0.0 };
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient1);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse1);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular1);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess1);
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
	glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);
	glFrontFace(GL_CW);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_NORMALIZE);
	glEnable(GL_DEPTH_TEST);
	teapotList = glGenLists(1);
	glNewList(teapotList, GL_COMPILE);
	glutSolidTeapot(1.0);
	glEndList();

	sphereList = glGenLists(1);
	glNewList(sphereList, GL_COMPILE);
	glutSolidSphere(radius / 9, 25, 25);
	glEndList();
}
void renderTeapot(GLfloat x, GLfloat y, GLfloat z,
	GLfloat rx, GLfloat ry, GLfloat rz, GLfloat rt,
	GLfloat ambr, GLfloat ambg, GLfloat ambb,
	GLfloat difr, GLfloat difg, GLfloat difb,
	GLfloat specr, GLfloat specg, GLfloat specb, GLfloat shine)
{
	GLfloat mat[4];
	glPushMatrix();
	glTranslatef(x, y, z);
	glRotatef(rt, rx, ry, rz);

	mat[0] = ambr; mat[1] = ambg; mat[2] = ambb; mat[3] = 1.0;
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat);
	mat[0] = difr; mat[1] = difg; mat[2] = difb;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat);
	mat[0] = specr; mat[1] = specg; mat[2] = specb;
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat);
	glMaterialf(GL_FRONT, GL_SHININESS, shine * 128.0);
	glCallList(teapotList);
	glPopMatrix();
}
void rendersphere(GLfloat x, GLfloat y, GLfloat z,
	GLfloat rx, GLfloat ry, GLfloat rz, GLfloat rt)
{
	glPushMatrix();
	glRotatef(rt, rx, ry, rz);
	glTranslatef(x, y, z);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, emitLight);
	glutSolidSphere(radius / 9, 25, 25);
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, Noemit);
	glPopMatrix();

	glPushMatrix();
	glRotatef(rt, rx, ry, rz);
	glTranslatef(x, y, z);
	glLightfv(GL_LIGHT0, GL_POSITION, qaLightPosition);
	glPopMatrix();
}
GLfloat rx1 = 0.0;
GLfloat ry1 = 1.0;
GLfloat rz1 = 0.0;
GLfloat rt1 = 0.0;

void drawtepod(void)
{
	GLfloat x1 = 2.0;
	GLfloat y1 = 15.0;
	GLfloat z1 = 0.0;
	GLfloat specr1 = 1.0;
	GLfloat specg1 = 1.0;  // light color
	GLfloat specb1 = 1.0;

	GLfloat shine1 = 0.9;
	int i, j = 1;

	GLfloat ambr_list[64] = { 0.2, 0.2, 0.2, 0.2, 0.3, 0.4, 0.5, 0.4,
								   0.2, 0.2, 0.2, 0.3, 0.35, 0.4, 0.4, 0.5,
								   0.15, 0.15, 0.15, 0.25, 0.25, 0.25, 0.3, 0.3,
								   0.15, 0.15, 0.2, 0.2, 0.25, 0.35, 0.35, 0.35,
								   0.1, 0.1, 0.1, 0.2, 0.35, 0.4, 0.5, 0.55,
								   0.1, 0.15, 0.15, 0.25, 0.3, 0.35, 0.25, 0.25,
								   0.1, 0.15, 0.15, 0.2, 0.25, 0.3, 0.3, 0.3,
								   0.15, 0.15, 0.15, 0.25, 0.25, 0.3, 0.35, 0.35,
	};

	GLfloat ambg_list[64] = { 0.5, 0.5, 0.5, 0.5, 0.6, 0.65, 0.65, 0.5,
							   0.5, 0.5, 0.5, 0.7, 0.7, 0.7, 0.7, 0.7,
							   0.6, 0.6, 0.6, 0.55, 0.55, 0.55, 0.55, 0.55,
							   0.6, 0.6, 0.65, 0.6, 0.6, 0.55, 0.55, 0.55,
							   0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35,
							   0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3,
							   0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2,
							   0.15, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15
	};

	GLfloat ambb_list[64] = { 0.3, 0.3, 0.3, 0.3, 0.5, 0.65, 0.65, 0.4,
							   0.4, 0.4, 0.4, 0.5, 0.4, 0.4, 0.4, 0.4,
							   0.65, 0.65, 0.65, 0.6, 0.6, 0.6, 0.6, 0.65,
							   0.6, 0.6, 0.6, 0.6, 0.65, 0.6, 0.6, 0.6,
							   0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6,
							   0.65, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6,
							   0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.65,
							   0.55, 0.6, 0.6, 0.6, 0.6, 0.6, 0.6, 0.5

	};

	GLfloat difr_list[64] = { 0.3, 0.3, 0.3, 0.3, 0.4, 0.4, 0.5, 0.65,
							   0.15, 0.15, 0.2, 0.25, 0.4, 0.55, 0.7, 0.85,
							   0.2, 0.2, 0.2, 0.35, 0.5, 0.65, 0.8, 0.95,
							   0.2, 0.2, 0.25, 0.4, 0.5, 0.6, 0.7, 0.85,
							   0.1, 0.1, 0.2, 0.3, 0.3, 0.4, 0.5, 0.6,
							   0.1, 0.1, 0.15, 0.25, 0.3, 0.45, 0.7, 0.9,
							   0.1, 0.15, 0.25, 0.3, 0.4, 0.5, 0.7, 0.95,
							   0.15, 0.15, 0.25, 0.35, 0.4, 0.5, 0.7, 0.85
	};

	GLfloat difg_list[64] = { 0.75, 0.8, 0.85, 0.9, 0.8, 0.85, 0.85, 0.7,
							   0.7, 0.75, 0.8, 0.8, 0.85, 0.9, 0.75, 0.8,
							   0.5, 0.55, 0.6, 0.55, 0.55, 0.55, 0.55, 0.5,
							   0.4, 0.45, 0.45, 0.5, 0.55, 0.55, 0.5, 0.45,
							   0.35, 0.4, 0.35, 0.35, 0.35, 0.35, 0.35, 0.35,
							   0.3, 0.35, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3,
							   0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2,
							   0.15, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15, 0.15,
	};

	GLfloat difb_list[65] = { 0.55, 0.6, 0.65, 0.7, 0.5, 0.5, 0.5, 0.6,
							   0.6, 0.65, 0.7, 0.75, 0.75, 0.75, 0.75, 0.8,
							   0.7, 0.75, 0.75, 0.7, 0.7, 0.7, 0.75, 0.7,
							   0.55, 0.6, 0.65, 0.65, 0.7, 0.75, 0.75, 0.75,
							   0.6, 0.65, 0.7, 0.7, 0.7, 0.65, 0.65, 0.65,
							   0.6, 0.6, 0.55, 0.6, 0.6, 0.65, 0.65, 0.65,
							   0.6, 0.6, 0.65, 0.65, 0.65, 0.65, 0.65, 0.65,
							   0.65, 0.7, 0.7, 0,7, 0.75, 0.65, 0.6, 0.5
	};
	int c = 0;
	//first column
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 1;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 2;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 3;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 4;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 5;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 6;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 7;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	//second  column
	y1 = 13;
	c = 8;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 9;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 10;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 11;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 12;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 13;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 14;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 15;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);


	//third  column
	y1 = 11;
	c = 16;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 17;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 18;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 19;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 20;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 21;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 22;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 23;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	//fourth  column
	y1 = 9;
	c = 24;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 25;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 26;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 27;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 28;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 29;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 30;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 31;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	//fifth  column
	y1 = 7;
	c = 32;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 33;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 34;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 35;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 36;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 37;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 38;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 39;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);


	//sixth  column
	y1 = 5;
	c = 40;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 41;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 42;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 43;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 44;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 45;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 46;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 47;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);


	//seventh  column
	y1 = 3;
	c = 48;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 49;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 50;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 51;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 52;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 53;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 54;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 55;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);


	//eight  column
	y1 = 1;
	c = 56;
	renderTeapot(x1, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);

	c = 57;
	renderTeapot(x1 + 3, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 58;
	renderTeapot(x1 + 6, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	//c=59;
	renderTeapot(x1 + 9, y1, z1, rx1, ry1, rz1, rt1, 0.25, 0.15, 0.6,
		0.35, 0.15, 0.7, specr1, specg1, specb1, shine1);

	//c=60;
	renderTeapot(x1 + 12, y1, z1, rx1, ry1, rz1, rt1, 0.25, 0.15, 0.6,
		0.45, 0.15, 0.75, specr1, specg1, specb1, shine1);
	c = 61;
	renderTeapot(x1 + 15, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 62;
	renderTeapot(x1 + 18, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);
	c = 63;
	renderTeapot(x1 + 21, y1, z1, rx1, ry1, rz1, rt1, ambr_list[c], ambg_list[c], ambb_list[c],
		difr_list[c], difg_list[c], difb_list[c], specr1, specg1, specb1, shine1);








	int c1 = 0;
	//first column
	rendersphere(x1 + 1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 1;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 2;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 3;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 4;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 5;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 6;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 7;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);

	//second  column
	y1 = 13;
	c1 = 8;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 9;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 10;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 11;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 12;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 13;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 14;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 15;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);


	//third  column
	y1 = 11;
	c1 = 16;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 17;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 18;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 19;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 20;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 21;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 22;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 23;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);

	//fourth  column
	y1 = 9;
	c1 = 24;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 25;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 26;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 27;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 28;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 29;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 30;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 31;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);

	//fifth  column
	y1 = 7;
	c1 = 32;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 33;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 34;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 35;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 36;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 37;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 38;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 39;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);


	//sixth  column
	y1 = 5;
	c1 = 40;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 41;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 42;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 43;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 44;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 45;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 46;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 47;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);


	//seventh  column
	y1 = 3;
	c1 = 48;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 49;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 50;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 51;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 52;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 53;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 54;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 55;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);


	//eight  column
	y1 = 1;
	c1 = 56;
	rendersphere(x1, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 57;
	rendersphere(x1 + 3, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 58;
	rendersphere(x1 + 6, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 59;
	rendersphere(x1 + 9, y1, z1, rx1, ry1, rz1, rt1);

	c1 = 60;
	rendersphere(x1 + 12, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 61;
	rendersphere(x1 + 15, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 62;
	rendersphere(x1 + 18, y1, z1, rx1, ry1, rz1, rt1);
	c1 = 63;
	rendersphere(x1 + 21, y1, z1, rx1, ry1, rz1, rt1);






}
void rotate() {

	rt1 += 4.0;
	rx1 += 4.0;
	ry1 += 4.0;
	rz1 += 4.0;
	if (ry1 > 360.0) {
		ry1 -= 360.0*floor(ry1 / 360.0);   // Don't allow overflow
	}
	ry1 += 0.1;
	glutPostRedisplay();
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	drawtepod();
	rotate();



	glFlush();
}

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (w <= h)
		glOrtho(0.0, 16.0, 0.0, 16.0*(GLfloat)h / (GLfloat)w,
			-10.0, 10.0);
	else
		glOrtho(0.0, 16.0*(GLfloat)w / (GLfloat)h, 0.0, 16.0,
			-10.0, 10.0);
	glMatrixMode(GL_MODELVIEW);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
		break;

	}
}

/*
 * Main Loop
 */
int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Teapot");
	glutCreateWindow(argv[0]);
	init();
	glutReshapeFunc(reshape);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}

