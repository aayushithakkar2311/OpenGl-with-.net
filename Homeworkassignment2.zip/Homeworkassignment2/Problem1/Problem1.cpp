/*

   Computer graphics Homework assignment1

			CSC 706 HW2
			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <GL\glew.h>
#include <GL\freeglut.h>
#include <iostream>
#include <fstream>
#include <cstdio>

void setWindow(float left, float right, float bottom, float top)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(left, right, bottom, top);
}
void setViewport(float left, float right, float bottom, float top)
{
	glViewport(left, bottom, right - left, top - bottom);
}


void myInit(void) {
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0, 0.0, 0.0);
	glPointSize(2.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 1024.0, 0.0, 768.0);
}

void drawDino() {
	std::ifstream dinosaur;
	dinosaur.open("Brontoi.dat");
	int number_of_poly_lines = 0;
	dinosaur >> number_of_poly_lines;
	int number_of_vertices = 0;
	for (int i = 0; i < number_of_poly_lines; i++) {
		dinosaur >> number_of_vertices;
		glBegin(GL_LINE_STRIP);
		for (int j = 0; j < number_of_vertices; j++) {
			double x, y;
			dinosaur >> x >> y;
			glVertex2d(x, y);
		}
		glEnd();
	}
	glFlush();
}
//<<<<<<<<<<<<<<<<<<<<<<<< main >>>>>>>>>>>>>>>>>>>>>>
void one()
{

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(250, 2950, 0);
	drawDino();
	glPopMatrix();


	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(600, 3200, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1000, 3350, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1500, 3300, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2000, 3000, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2200, 2550, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2150, 2150, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2000, 1800, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1700, 1550, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1200, 1450, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(650, 1450, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(300, 1700, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(150, 2150, 0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(150, 2550, 0);
	drawDino();
	glPopMatrix();
}
void two()
{

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6000, 2950, 0);
	glRotatef(30, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();


	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6400, 3250, 0);
	glRotatef(20, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6750, 3450, 0);
	glRotatef(0, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7200, 3500, 0);
	glRotatef(-20, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7600, 3350, 0);
	glRotatef(-40, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(8100, 3150, 0);
	glRotatef(-90, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(8100, 2650, 0);
	glRotatef(-90, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(8100, 2200, 0);
	glRotatef(-125, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7900, 1900, 0);
	glRotatef(-140, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7600, 1650, 0);
	glRotatef(-180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7100, 1650, 0);
	glRotatef(-180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6600, 1600, 0);
	glRotatef(-230, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6300, 2000, 0);
	glRotatef(-250, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6050, 2450, 0);
	glRotatef(-280, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();
}
void three()
{

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(700, 7000, 0);
	glRotatef(190, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();


	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(950, 7150, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1300, 7200, 0);
	glRotatef(170, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1650, 7200, 0);
	glRotatef(160, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1950, 7000, 0);
	glRotatef(130, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2150, 6700, 0);
	glRotatef(110, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2200, 6300, 0);
	glRotatef(90, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(2150, 5900, 0);
	glRotatef(70, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1950, 5550, 0);
	glRotatef(50, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1600, 5300, 0);
	glRotatef(20, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(1200, 5200, 0);
	glRotatef(0, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(800, 5250, 0);
	glRotatef(-20, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(500, 5400, 0);
	glRotatef(-40, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(300, 5750, 0);
	glRotatef(-65, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(250, 6150, 0);
	glRotatef(-90, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(250, 6450, 0);
	glRotatef(-110, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(450, 6800, 0);
	glRotatef(-140, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

}
void four()
{
	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5300, 7000, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();


	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5650, 7200, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6000, 7350, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6450, 7350, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6950, 7150, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7150, 6700, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7200, 6300, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(7150, 5900, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6950, 5550, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6600, 5300, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(6200, 5200, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5600, 5250, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5200, 5700, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5000, 6200, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();

	glPushMatrix();
	glScalef(0.1, 0.1, 0.1);
	glTranslatef(5100, 6600, 0);
	glRotatef(180, 0.0, 0.0, 1.0);
	drawDino();
	glPopMatrix();


}

void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	one();
	two();
	three();
	four();
}



int main(int argc, char *argv[]) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1000, 1000);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Problem1");
	glutDisplayFunc(myDisplay);
	myInit();
	glutMainLoop();
}
