/*

   Computer graphics Homework assignment1

			CSC 706 HW2
			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>
#include "Canvas_freeglut.h"
#define PI 3.1415926535898
static int value = 0;

void display();
void GoMenu(int value);


void Circle(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);

	static const int circle_points = 360;
	static const float angle = 2.0f * 3.0f / circle_points;
	glBegin(GL_POLYGON);
	double angle1 = 0.0;
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i < circle_points; i++)

	{
		glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	glEnd();
	glPopMatrix();
}

void Poligon(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);
	Point2 coordinates[5];
	Point2 innerCoordinates[5];
	float innerRadius = 0.05;

	static const int circle_points = 5;
	static const float angle = 2.0f * PI / circle_points;
	glBegin(GL_LINE_LOOP);
	double angle1 = 0.0;
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (int i = 0; i < circle_points; i++)
	{
		Point2 point;
		point.x = radius * cos(angle1);
		point.y = radius * sin(angle1) * 2;
		coordinates[i] = point;
		glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	glEnd();

	double angle2 = 0.0;
	for (int i = 0; i < circle_points; i++)
	{
		Point2 point;
		point.x = innerRadius * cos(angle2);
		point.y = innerRadius * sin(angle2) * 2;
		innerCoordinates[i] = point;
		//glVertex2d(innerRadius * cos(angle2), innerRadius * sin(angle2) * 2);
		angle2 += angle;
	}

	glBegin(GL_LINE_LOOP);
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (int i = 0; i < circle_points; i++)
	{
		//glVertex2d(innerCoordinates[i].x, innerCoordinates[i].y);


		glVertex2d(coordinates[i].x, coordinates[i].y);
		if (i == circle_points - 1) {
			glVertex2d((innerCoordinates[i].x + innerCoordinates[0].x) / 2, (innerCoordinates[i].y + innerCoordinates[0].y) / 2);
		}
		else {
			glVertex2d((innerCoordinates[i].x + innerCoordinates[i + 1].x) / 2, (innerCoordinates[i].y + innerCoordinates[i + 1].y) / 2);
		}
	}
	glEnd();
	glPopMatrix();
}

void Triangle(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);
	Point2 tCoordinates[3];
	Point2 tInnerCoordinates[3];
	float tInnerRadius = 0.05;

	static const int circle_points = 3;
	static const float angle = 2.0f * PI / circle_points;
	glBegin(GL_LINE_LOOP);
	double angle1 = 0.0;
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i < circle_points; i++)
	{

		Point2 point;
		point.x = radius * cos(angle1);
		point.y = radius * sin(angle1) * 2;
		tCoordinates[i] = point;
		glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	glEnd();

	double angle2 = 0.0;
	for (int i = 0; i < circle_points; i++)
	{
		Point2 point;
		point.x = tInnerRadius * cos(angle2);
		point.y = tInnerRadius * sin(angle2) * 2;
		tInnerCoordinates[i] = point;
		//glVertex2d(innerRadius * cos(angle2), innerRadius * sin(angle2) * 2);
		angle2 += angle;
	}

	glBegin(GL_LINE_LOOP);
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (int i = 0; i < circle_points; i++)
	{
		glVertex2d(tCoordinates[i].x, tCoordinates[i].y);
		if (i == circle_points - 1) {
			glVertex2d((tInnerCoordinates[i].x + tInnerCoordinates[0].x) / 2, (tInnerCoordinates[i].y + tInnerCoordinates[0].y) / 2);
		}
		else {
			glVertex2d((tInnerCoordinates[i].x + tInnerCoordinates[i + 1].x) / 2, (tInnerCoordinates[i].y + tInnerCoordinates[i + 1].y) / 2);
		}
	}
	glEnd();
	glPopMatrix();
}

void star(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);
	Point2 sCoordinates[7];
	Point2 sInnerCoordinates[7];
	float tInnerRadius = 0.05;

	static const int circle_points = 7;
	static const float angle = 2.0f * PI / circle_points;
	glBegin(GL_LINE_LOOP);
	double angle1 = 0.0;
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i < circle_points; i++)
	{

		Point2 point;
		point.x = radius * cos(angle1);
		point.y = radius * sin(angle1) * 2;
		sCoordinates[i] = point;
		//glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	//glEnd();

	double angle2 = 0.0;
	for (int i = 0; i < circle_points; i++)
	{
		Point2 point;
		point.x = tInnerRadius * cos(angle2);
		point.y = tInnerRadius * sin(angle2) * 2;
		sInnerCoordinates[i] = point;
		//glVertex2d(innerRadius * cos(angle2), innerRadius * sin(angle2) * 2);
		angle2 += angle;
	}

	glBegin(GL_LINE_LOOP);
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (int i = 0; i < circle_points; i++)
	{
		glVertex2d(sCoordinates[i].x, sCoordinates[i].y);
		if (i == circle_points - 1) {
			glVertex2d((sInnerCoordinates[i].x + sInnerCoordinates[0].x) / 2, (sInnerCoordinates[i].y + sInnerCoordinates[0].y) / 2);
		}
		else {
			glVertex2d((sInnerCoordinates[i].x + sInnerCoordinates[i + 1].x) / 2, (sInnerCoordinates[i].y + sInnerCoordinates[i + 1].y) / 2);
		}
	}
	glEnd();
	glPopMatrix();
}

void Hexgon(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);
	Point2 sCoordinates[6];
	Point2 sInnerCoordinates[6];
	float tInnerRadius = 0.05;

	static const int circle_points = 6;
	static const float angle = 2.0f * PI / circle_points;
	glBegin(GL_LINE_LOOP);
	double angle1 = 0.0;
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i < circle_points; i++)
	{

		Point2 point;
		point.x = radius * cos(angle1);
		point.y = radius * sin(angle1) * 2;
		sCoordinates[i] = point;
		glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	glEnd();

	double angle2 = 0.0;
	for (int i = 0; i < circle_points; i++)
	{
		Point2 point;
		point.x = tInnerRadius * cos(angle2);
		point.y = tInnerRadius * sin(angle2) * 2;
		sInnerCoordinates[i] = point;
		//glVertex2d(innerRadius * cos(angle2), innerRadius * sin(angle2) * 2);
		angle2 += angle;
	}

	glBegin(GL_LINE_LOOP);
	//glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (int i = 0; i < circle_points; i++)
	{
		glVertex2d(sCoordinates[i].x, sCoordinates[i].y);
		if (i == circle_points - 1) {
			glVertex2d((sInnerCoordinates[i].x + sInnerCoordinates[0].x) / 2, (sInnerCoordinates[i].y + sInnerCoordinates[0].y) / 2);
		}
		else {
			glVertex2d((sInnerCoordinates[i].x + sInnerCoordinates[i + 1].x) / 2, (sInnerCoordinates[i].y + sInnerCoordinates[i + 1].y) / 2);
		}
	}
	glEnd();

	static const int circle_points1 = 360;
	static const float cAngle = 2.0f * PI / circle_points1;
	glBegin(GL_LINE_LOOP);
	double angle3 = 0.0;
	double cRadius = 0.0425;
	for (int i = 0; i < circle_points1; i++)
	{
		glVertex2d(cRadius * cos(angle3), cRadius * sin(angle3) * 2);
		angle3 += cAngle;
	}
	glEnd();
	glPopMatrix();
}


void mouse(int btn, int state, int x, int y)
{
	//if (btn == GLUT_LEFT_BUTTON && state == GLUT_UP)
		//exit(0);

}

void display1() {
	glClear(GL_COLOR_BUFFER_BIT);
	Triangle(0.0f, 0.0f, 0.3f);
	glFlush();
}
void display2() {
	glClear(GL_COLOR_BUFFER_BIT);
	Poligon(0.0f, 0.0f, 0.3f);
	glFlush();
}
void display3() {
	glClear(GL_COLOR_BUFFER_BIT);
	star(0.0f, 0.0f, 0.3f);
	glFlush();
}
void display4() {
	glClear(GL_COLOR_BUFFER_BIT);
	Hexgon(0.0f, 0.0f, 0.3f);
	glFlush();
}

void display() {
	glClear(GL_COLOR_BUFFER_BIT);
	switch (value)
	{
	case 1:
		glColor3f(1.0f, 0.0f, 0.0f);
		Triangle(0.0f, 0.0f, 0.3f);
		break;
	case 2:
		glColor3f(0.0f, 1.0f, 0.0f);
		Triangle(0.0f, 0.0f, 0.3f);
		break;
	case 3:
		glColor3f(0.0f, 0.0f, 1.0f);
		Triangle(0.0f, 0.0f, 0.3f);
		break;
	case 4:
		glColor3f(1.0f, 0.0f, 0.0f);
		Poligon(0.0f, 0.0f, 0.3f);
		break;
	case 5:
		glColor3f(0.0f, 1.0f, 0.0f);
		Poligon(0.0f, 0.0f, 0.3f);
		break;
	case 6:
		glColor3f(0.0f, 0.0f, 1.0f);
		Poligon(0.0f, 0.0f, 0.3f);
		break;
	case 7:
		glColor3f(1.0f, 0.0f, 0.0f);
		star(0.0f, 0.0f, 0.3f);
		break;
	case 8:
		glColor3f(0.0f, 1.0f, 0.0f);
		star(0.0f, 0.0f, 0.3f);
		break;
	case 9:
		glColor3f(0.0f, 0.0f, 1.0f);
		star(0.0f, 0.0f, 0.3f);
		break;
	case 10:
		glColor3f(1.0f, 0.0f, 0.0f);
		Hexgon(0.0f, 0.0f, 0.3f);
		break;
	case 11:
		glColor3f(0.0f, 1.0f, 0.0f);
		Hexgon(0.0f, 0.0f, 0.3f);
		break;
	case 12:
		glColor3f(0.0f, 0.0f, 1.0f);
		Hexgon(0.0f, 0.0f, 0.3f);
		break;

	default:
		glColor3f(0.0f, 0.0f, 0.0f);
		Triangle(0.0f, 0.0f, 0.3f);
		break;
	}
	glFlush();
}


void init()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
}


int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1200, 1200);
	glutInitWindowPosition(50, 50);
	glutCreateWindow(argv[0]);
	glutCreateWindow("Ngon");
	int sub1 = glutCreateMenu(GoMenu);
	glutAddMenuEntry("red", 1);
	glutAddMenuEntry("green", 2);
	glutAddMenuEntry("blue", 3);
	int sub2 = glutCreateMenu(GoMenu);
	glutAddMenuEntry("red", 4);
	glutAddMenuEntry("green", 5);
	glutAddMenuEntry("blue", 6);
	int sub3 = glutCreateMenu(GoMenu);
	glutAddMenuEntry("red", 7);
	glutAddMenuEntry("green", 8);
	glutAddMenuEntry("blue", 9);
	int sub4 = glutCreateMenu(GoMenu);
	glutAddMenuEntry("red", 10);
	glutAddMenuEntry("green", 11);
	glutAddMenuEntry("blue", 12);
	glutCreateMenu(GoMenu);
	glutAddSubMenu("Triangle", sub1);
	glutAddSubMenu("Polygon", sub2);
	glutAddSubMenu("Star", sub3);
	glutAddSubMenu("Hexagon", sub4);
	//glutAddSubMenu("Star", sub3);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutDisplayFunc(display);
	init();
	glutMainLoop();

}

void GoMenu(int num) {
	value = num;
	glutPostRedisplay();
}

