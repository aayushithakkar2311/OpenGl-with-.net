/*

   Computer graphics Homework assignment1

			CSC 706 HW2
			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <gl/glut.h>
#include <stdio.h> 
#include <math.h>
#include <GL/gl.h>
#include "canvas_freeglut.h"

const int screenWidth = 400;
const int screenHeight = screenWidth;
const float aspectRatio = screenWidth / (float)screenHeight;
const int diagnosticLevel = 20;
const double Pi = 4 * atan(1.0);

char file[] = "The yin-yang symbol";

Canvas cvs(screenWidth, screenHeight, file);

void drawArc(Point2 center, float radius, float startAngle, float sweep, Canvas& cvs)
{
	const int n = 30; // no. of intermediate segments in arc
	float angle = startAngle * Pi / 180; // initial angle 
	float angleInc = sweep * Pi / (180 * n); //increment in angle
	float cx = center.getX(), cy = center.getY();
	cvs.moveTo(cx + radius * cos(angle), cy + radius * sin(angle));
	glBegin(GL_POLYGON);
	glVertex2f(cx, cy);
	glVertex2d(cx + radius * cos(angle), cy + radius * sin(angle));
	angle += angleInc;
	for (int i = 0; i <= n; i++, angle += angleInc)
		glVertex2f(cx + radius * cos(angle), cy + radius * sin(angle));
	glEnd();
}

void drawCircle(int n, float cx, float cy, float radius, float Angle1, Canvas& cvs)
{
	double angle = Angle1 * Pi / 180;  // Initial angle
	double angleInc = 2 * Pi / n;         //increment in angle 
	cvs.moveTo(radius * cos(angle) + cx, radius * sin(angle) + cy);
	for (int i = 0; i < n; i++)
	{
		angle += angleInc;
		cvs.lineTo(radius * cos(angle) + cx, radius * sin(angle) + cy);
	}
}


void myCenter(GLsizei W, GLsizei H) {
	if (H*aspectRatio > W)  // use (global) window aspect ratio
							// Case (a): R > W/H - Reach all the way across
		cvs.setViewport(0, W, (GLsizei)((H*aspectRatio - W) / (2.0*aspectRatio)),
		(GLsizei)((H*aspectRatio + W) / (2.0*aspectRatio)));
	else
		// Case (b): R < W/H - Reach all the way from top to bottom
		cvs.setViewport((GLsizei)((W - H * aspectRatio) / 2),
		(GLsizei)((W + H * aspectRatio) / 2), 0, H);
}

void display(void)
{
	const double radius = 2.0;
	cvs.clearScreen();
	cvs.setWindow(-3, 3, -3, 3);
	Point2 pt;
	pt.set(0.0, 0.0);
	drawCircle(500, 0.0, 0.0, radius, 0.0, cvs);
	drawArc(pt, radius, 0.0, 180.0, cvs);
	pt.set(0.0 - radius / 2, 0.0);
	drawArc(pt, radius / 2, 180.0, 180.0, cvs);
	cvs.setColor(1.0, 1.0, 1.0);
	drawArc(pt, radius / 8, 0.0, 360.0, cvs);
	pt.set(0.0 + radius / 2, 0.0);
	drawArc(pt, radius / 2, 0.0, 180.0, cvs);
	cvs.setColor(0.0, 0.0, 0.0);
	drawArc(pt, radius / 8, 0.0, 360.0, cvs);
	glFlush();
	glutSwapBuffers();
}


int main(int argc, char** argv)
{
	cvs.setViewport(0, screenWidth, 0, screenHeight);
	glutReshapeFunc(myCenter);
	glutDisplayFunc(display);
	glutMainLoop();
	return (0);
}