/*

   Computer graphics Homework assignment1

			CSC 706 HW1
			Team Members

		**********************
		*				     *
		*  Aayushi Thakkar   *
		*  Nikitha Pulluri   *
		*  Kinjalben Parmar  *
		*                    *
		***********************

*/
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <math.h>
#define PI 3.1415926535898

GLubyte grassMask[] = {
 0x08,  0x08,  0x08,  0x08,  0x00,  0x00,  0x00,  0x00,
 0x0C,  0x0C,  0x0C,  0x0C,  0x00,  0x00,  0x00,  0x00,
 0x44,  0x44,  0x44,  0x44,  0x00,  0x00,  0x00,  0x00,
 0x60,  0x60,  0x60,  0x60,  0x00,  0x00,  0x00,  0x00,
 0x20,  0x20,  0x20,  0x20,  0x00,  0x00,  0x00,  0x00,
 0x08,  0x08,  0x08,  0x08,  0x00,  0x00,  0x00,  0x00,
 0x0C,  0x0C,  0x0C,  0x0C,  0x00,  0x00,  0x00,  0x00,
 0x44,  0x44,  0x44,  0x44,  0x00,  0x00,  0x00,  0x00,
 0x60,  0x60,  0x60,  0x60,  0x00,  0x00,  0x00,  0x00,
 0x20,  0x20,  0x20,  0x20,  0x00,  0x00,  0x00,  0x00,
 0x08,  0x08,  0x08,  0x08,  0x00,  0x00,  0x00,  0x00,
 0x0C,  0x0C,  0x0C,  0x0C,  0x00,  0x00,  0x00,  0x00,
 0x44,  0x44,  0x44,  0x44,  0x00,  0x00,  0x00,  0x00,
 0x60,  0x60,  0x60,  0x60,  0x00,  0x00,  0x00,  0x00,
 0x20,  0x20,  0x20,  0x20,  0x00,  0x00,  0x00,  0x00,
 0x00,  0x00,  0x00,  0x00,  0x00,  0x00,  0x00,  0x00
};


GLubyte frontHouse[] = {
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,
 0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11,  0x11
};


void Circle(float x, float y, float radius) {
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glTranslatef(x, y, 0.0f);

	static const int circle_points = 360;
	static const float angle = 2.0f * 3.0f / circle_points;
	glBegin(GL_POLYGON);
	double angle1 = 0.0;
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i < circle_points; i++)

	{
		glVertex2d(radius * cos(angle1), radius * sin(angle1) * 2);
		angle1 += angle;
	}
	glEnd();
	glPopMatrix();
}


void well()
{
	//well//

	glBegin(GL_POLYGON);
	glColor3ub(204, 51, 0);
	glVertex2f(0.5f, -0.35f);
	glVertex2f(0.5f, -0.55f);
	glVertex2f(0.55f, -0.575f);
	glVertex2f(0.6f, -0.59f);
	glVertex2f(0.7f, -0.59f);
	glVertex2f(0.75f, -0.575f);
	glVertex2f(0.8f, -0.55f);
	glVertex2f(0.8f, -0.35f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(255, 102, 51);
	glVertex2f(0.5f, -0.35f);
	glVertex2f(0.55f, -0.375f);
	glVertex2f(0.6f, -0.38f);
	glVertex2f(0.7f, -0.38f);
	glVertex2f(0.75f, -0.375f);
	glVertex2f(0.8f, -0.35f);
	glVertex2f(0.75f, -0.33f);
	glVertex2f(0.7f, -0.325f);
	glVertex2f(0.6f, -0.325f);
	glVertex2f(0.55f, -0.33f);
	glEnd();

	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	glColor3ub(204, 51, 0);
	glVertex2f(0.5f, -0.35f);
	glVertex2f(0.55f, -0.33f);//
	glVertex2f(0.55f, -0.33f);
	glVertex2f(0.6f, -0.325f);//
	glVertex2f(0.6f, -0.325f);
	glVertex2f(0.7f, -0.325f);//
	glVertex2f(0.7f, -0.325f);
	glVertex2f(0.75f, -0.33f);//
	glVertex2f(0.75f, -0.33f);
	glVertex2f(0.8f, -0.35f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(194, 194, 163);
	glVertex2f(0.81f, -0.43f);
	glVertex2f(0.83f, -0.5f);
	glVertex2f(0.88f, -0.5f);
	glVertex2f(0.9f, -0.43f);
	glVertex2f(0.88f, -0.42f);
	glVertex2f(0.83f, -0.42f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(38, 154, 214);
	glVertex2f(0.815f, -0.43f);
	glVertex2f(0.832f, -0.44f);
	glVertex2f(0.878f, -0.44f);
	glVertex2f(0.895f, -0.43f);
	glVertex2f(0.896f, -0.425f);
	glVertex2f(0.83f, -0.425f);
	glEnd();

	glLineWidth(3);
	glBegin(GL_LINE_STRIP);
	glColor3ub(194, 194, 163);
	glVertex2f(0.81f, -0.43f);
	glVertex2f(0.83f, -0.39f);//
	glVertex2f(0.83f, -0.39f);
	glVertex2f(0.85f, -0.39f);//
	glVertex2f(0.85f, -0.39f);
	glVertex2f(0.88f, -0.39f);//
	glVertex2f(0.88f, -0.39f);
	glVertex2f(0.9f, -0.43f);//
	glEnd();

	glLineWidth(2.5);
	glBegin(GL_LINE_STRIP);
	glColor3ub(230, 172, 0);
	glVertex2f(0.855f, -0.385f);
	glVertex2f(0.83f, -0.45f);//
	glVertex2f(0.83f, -0.45f);
	glVertex2f(0.825f, -0.5f);//
	glVertex2f(0.825f, -0.5f);
	glVertex2f(0.82f, -0.53f);//
	glVertex2f(0.82f, -0.53f);
	glVertex2f(0.83f, -0.55f);//
	glVertex2f(0.83f, -0.55f);
	glVertex2f(0.92f, -0.53f);//
	glEnd();
}

void bird()
{
	//first bird//

	int i;

	GLfloat mm = 0.282f; GLfloat nn = .801f; GLfloat radiusmm = .01f;
	int triangleAmount = 20;
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(225, 225, 208);
	glVertex2f(mm, nn); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			mm + (radiusmm * cos(i * twicePi / triangleAmount)),
			nn + (radiusmm * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	glBegin(GL_POLYGON);
	glColor3ub(225, 225, 208);
	glVertex2f(0.20f, 0.8f);
	glVertex2f(0.21f, 0.79f);
	glVertex2f(0.22f, 0.78f);
	glVertex2f(0.26f, 0.77f);
	glVertex2f(0.29f, 0.79f);
	glVertex2f(0.301f, 0.8f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(217, 217, 217);
	glVertex2f(0.275f, 0.8f);
	glVertex2f(0.25f, 0.8f);
	glVertex2f(0.24f, 0.84f);
	glEnd();


	glBegin(GL_TRIANGLES);
	glColor3ub(242, 242, 242);
	glVertex2f(0.275f, 0.8f);
	glVertex2f(0.244f, 0.8f);
	glVertex2f(0.22f, 0.83f);
	glEnd();

	//2nd bird//

	glBegin(GL_POLYGON);
	glColor3ub(225, 225, 208);
	glVertex2f(0.325f, 0.8f);
	glVertex2f(0.335f, 0.79f);
	glVertex2f(0.345f, 0.78f);
	glVertex2f(0.365f, 0.77f);
	glVertex2f(0.415f, 0.79f);
	glVertex2f(0.426f, 0.8f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(217, 217, 217);
	glVertex2f(0.4f, 0.8f);
	glVertex2f(0.375f, 0.8f);
	glVertex2f(0.365f, 0.84f);
	glEnd();


	glBegin(GL_TRIANGLES);
	glColor3ub(242, 242, 242);
	glVertex2f(0.4f, 0.8f);
	glVertex2f(0.369f, 0.8f);
	glVertex2f(0.345f, 0.83f);
	glEnd();

	GLfloat mmm = 0.407f; GLfloat nnn = .801f; GLfloat radiusmmm = .01f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(225, 225, 208);
	glVertex2f(mmm, nnn); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			mmm + (radiusmmm * cos(i * twicePi / triangleAmount)),
			nnn + (radiusmmm * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	//3rd bird//

	glBegin(GL_POLYGON);
	glColor3ub(225, 225, 208);
	glVertex2f(-0.32f, 0.8f);
	glVertex2f(-0.31f, 0.79f);
	glVertex2f(-0.3f, 0.78f);
	glVertex2f(-0.26f, 0.77f);
	glVertex2f(-0.23f, 0.79f);
	glVertex2f(-0.219f, 0.8f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(217, 217, 217);
	glVertex2f(-0.245f, 0.8f);
	glVertex2f(-0.27f, 0.8f);
	glVertex2f(-0.28f, 0.84f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.245f, 0.8f);
	glVertex2f(-0.276f, 0.8f);
	glVertex2f(-0.3f, 0.83f);
	glEnd();

	GLfloat mmmm = -0.238f; GLfloat nnnn = .801f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(225, 225, 208);
	glVertex2f(mmmm, nnnn); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			mmmm + (radiusmmm * cos(i * twicePi / triangleAmount)),
			nnnn + (radiusmmm * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	//4th bird//

	GLfloat mmmmm = -0.368f; GLfloat nnnnn = .801f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(225, 225, 208);
	glVertex2f(mmmmm, nnnnn); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			mmmmm + (radiusmm * cos(i * twicePi / triangleAmount)),
			nnnnn + (radiusmm * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	glBegin(GL_POLYGON);
	glColor3ub(225, 225, 208);
	glVertex2f(-0.45f, 0.8f);
	glVertex2f(-0.44f, 0.79f);
	glVertex2f(-0.43f, 0.78f);
	glVertex2f(-0.39f, 0.77f);
	glVertex2f(-0.36f, 0.79f);
	glVertex2f(-0.349f, 0.8f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3ub(217, 217, 217);
	glVertex2f(-0.375f, 0.8f);
	glVertex2f(-0.40f, 0.8f);
	glVertex2f(-0.41f, 0.84f);
	glEnd();


	glBegin(GL_TRIANGLES);
	glColor3ub(242, 242, 242);
	glVertex2f(-0.375f, 0.8f);
	glVertex2f(-0.406f, 0.8f);
	glVertex2f(-0.43f, 0.83f);
	glEnd();


}

void grass() {

	//grass//

	glColor3f(0, 0.392, 0);
	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(grassMask);
	glBegin(GL_POLYGON);
	glColor3f(1.0, 1.0, 0.0);
	glVertex2f(-1.0, -1.0);
	glColor3f(0.0, 1.0, 0.0);
	glVertex2f(1.0, -1.0);
	glColor3f(0.0, 1.0, 0.0);
	glVertex2f(1.0, 0.0);
	glColor3f(0.0, 1.0, 0.0);
	glVertex2f(-1.0, 0.0);

	glEnd();
	glDisable(GL_POLYGON_STIPPLE);
}

void road() {

	//road//

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex2f(-1.0f, -0.6f);
	glVertex2f(-1.0f, -0.9f);
	glVertex2f(1.0f, -0.9f);
	glVertex2f(1.0f, -0.6f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 0.0f);
	glVertex2f(-1.0f, -0.74f);
	glVertex2f(-1.0f, -0.75f);
	glVertex2f(1.0f, -0.75f);
	glVertex2f(1.0f, -0.74f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 0.0f);
	glVertex2f(-1.0f, -0.76f);
	glVertex2f(-1.0f, -0.77f);
	glVertex2f(1.0f, -0.77f);
	glVertex2f(1.0f, -0.76f);
	glEnd();
}

void sun() {

	//sun//

	glBegin(GL_POLYGON);
	glColor3f(0.7f, 0.85f, 0.9f);
	glVertex2f(-1.0, 0.0);
	glVertex2f(1.0, 0.0);
	glVertex2f(1.0, 1.0);
	glVertex2f(-1.0, 1.0);
	glEnd();
	glColor3f(1.0f, 0.58f, 0.0f); Circle(-0.3f, 0.3f, 0.1f);

	//mountains//

	glBegin(GL_TRIANGLES);
	glColor3f(0.545, 0.27, 0.075);
	glVertex2f(-1.0, 0.0);
	glVertex2f(-0.25, 0.0);
	glColor3f(1.0, 1.0, 1.0); glVertex2f(-0.625, 0.9);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3f(0.545, 0.27, 0.075);
	glVertex2f(-0.35, 0.0);
	glVertex2f(0.4, 0.0);
	glColor3f(1.0, 1.0, 1.0); glVertex2f(0.025, 0.9);
	glEnd();
}

void houses() {

	//red House//

	glColor3f(1, 0, 0);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(0.0, -0.2);
	glVertex2f(0.1, -0.1);
	glBegin(GL_TRIANGLE_FAN);
	glVertex2f(0.2, -0.2);
	glVertex2f(0.2, -0.4);
	glVertex2f(0.0, -0.4);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(0.9, 0.85, 0.85);
	glVertex2f(0.125, -0.4);
	glVertex2f(0.075, -0.4);
	glVertex2f(0.075, -0.25);
	glVertex2f(0.125, -0.25);
	glEnd();

	//blue house//
	glBegin(GL_POLYGON);
	glColor3f(0.118, 0.565, 1);
	glVertex2f(-0.3, -0.1);
	glVertex2f(-0.1, -0.1);
	glVertex2f(-0.1, 0.2);
	glVertex2f(-0.2, 0.3);
	glVertex2f(-0.3, 0.2);
	glEnd();

	glEnable(GL_POLYGON_STIPPLE);
	glPolygonStipple(frontHouse);
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex2f(-0.175, -0.08);
	glVertex2f(-0.125, -0.08);
	glVertex2f(-0.125, 0.02);
	glVertex2f(-0.175, 0.02);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex2f(-0.175, 0.05);
	glVertex2f(-0.125, 0.05);
	glVertex2f(-0.125, 0.15);
	glVertex2f(-0.175, 0.15);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex2f(-0.275, -0.08);
	glVertex2f(-0.225, -0.08);
	glVertex2f(-0.225, 0.02);
	glVertex2f(-0.275, 0.02);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.0, 0.0);
	glVertex2f(-0.275, 0.05);
	glVertex2f(-0.225, 0.05);
	glVertex2f(-0.225, 0.15);
	glVertex2f(-0.275, 0.15);
	glEnd();
	glDisable(GL_POLYGON_STIPPLE);

	//yellow house//
	glBegin(GL_POLYGON);
	glColor3f(1, 1, 0);
	glVertex2f(-0.8, -0.5);
	glVertex2f(-0.6, -0.5);
	glVertex2f(-0.6, -0.35);
	glVertex2f(-0.7, -0.2);
	glVertex2f(-0.8, -0.35);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(0.19, 0.8, 0.6);
	glVertex2f(-0.675, -0.475);
	glVertex2f(-0.625, -0.475);
	glVertex2f(-0.625, -0.375);
	glVertex2f(-0.675, -0.375);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(0.19, 0.8, 0.6);
	glVertex2f(-0.775, -0.475);
	glVertex2f(-0.725, -0.475);
	glVertex2f(-0.725, -0.375);
	glVertex2f(-0.775, -0.375);
	glEnd();

	//green house//
	glBegin(GL_POLYGON);
	glColor3f(0, 0.392, 0.0);
	glVertex2f(-0.4, -0.4);
	glVertex2f(-0.2, -0.4);
	glVertex2f(-0.2, -0.25);
	glVertex2f(-0.3, -0.1);
	glVertex2f(-0.4, -0.25);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.5, 0);
	glVertex2f(-0.325, -0.4);
	glVertex2f(-0.275, -0.4);
	glVertex2f(-0.275, -0.25);
	glVertex2f(-0.325, -0.25);
	glEnd();


	//blue house//
	glBegin(GL_POLYGON);
	glColor3f(0.863, 0.078, 0.235);
	glVertex2f(-0.65, -0.25);
	glVertex2f(-0.45, -0.25);
	glVertex2f(-0.45, -0.1);
	glVertex2f(-0.55, 0.1);
	glVertex2f(-0.65, -0.1);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.973, 0.863);
	glVertex2f(-0.625, -0.225);
	glVertex2f(-0.565, -0.225);
	glVertex2f(-0.565, -0.125);
	glVertex2f(-0.625, -0.125);
	glEnd();
	glBegin(GL_POLYGON);
	glColor3f(1.0, 0.973, 0.86);
	glVertex2f(-0.535, -0.225);
	glVertex2f(-0.475, -0.225);
	glVertex2f(-0.475, -0.125);
	glVertex2f(-0.535, -0.125);
	glEnd();

}

void tree()
{
	//tree//

	glBegin(GL_POLYGON);
	glColor3ub(102, 51, 0);
	glVertex2f(0.58f, -0.15f);
	glVertex2f(0.65f, -0.2f);
	glVertex2f(0.565f, -0.17f);
	glVertex2f(0.56f, -0.25f);
	glVertex2f(0.525f, -0.17f);
	glVertex2f(0.45f, -0.2f);
	glVertex2f(0.52f, -0.15f);
	//glVertex2f(0.6f,-0.25f);
	glEnd();

	glBegin(GL_QUADS);
	glColor3ub(102, 51, 0);
	glVertex2f(0.52f, -0.15f);
	glVertex2f(0.52f, 0.23f);
	glVertex2f(0.58f, 0.23f);
	glVertex2f(0.58f, -0.15f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(102, 51, 0);
	glVertex2f(0.54f, 0.23f);
	glVertex2f(0.54f, 0.3f);
	glVertex2f(0.56f, 0.3f);
	glVertex2f(0.56f, 0.23f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(102, 51, 0);
	glVertex2f(0.56f, 0.23f);
	glVertex2f(0.59f, 0.29f);
	glVertex2f(0.6f, 0.28f);
	glVertex2f(0.58f, 0.23f);
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(102, 51, 0);
	glVertex2f(0.52f, 0.23f);
	glVertex2f(0.5f, 0.28f);
	glVertex2f(0.51f, 0.29f);
	glVertex2f(0.54f, 0.23f);
	glEnd();

	int i;

	GLfloat x = .55f; GLfloat y = .33f; GLfloat radius = .06f;
	int triangleAmount = 20;
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(x, y); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			x + (radius * cos(i * twicePi / triangleAmount)),
			y + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat a = .62f; GLfloat b = .31f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(a, b); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			a + (radius * cos(i * twicePi / triangleAmount)),
			b + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat c = .49f; GLfloat d = .31f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(c, d); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			c + (radius * cos(i * twicePi / triangleAmount)),
			d + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat e = .43f; GLfloat f = .35f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e, f); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e + (radius * cos(i * twicePi / triangleAmount)),
			f + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat g = .69f; GLfloat h = .35f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(g, h); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			g + (radius * cos(i * twicePi / triangleAmount)),
			h + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	GLfloat a1 = .69f; GLfloat b1 = .4f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(a1, b1); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			a1 + (radius * cos(i * twicePi / triangleAmount)),
			b1 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat c1 = .42f; GLfloat d1 = .4f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(c, d); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			c1 + (radius * cos(i * twicePi / triangleAmount)),
			d1 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat e1 = .43f; GLfloat f1 = .44f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e1, f1); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e1 + (radius * cos(i * twicePi / triangleAmount)),
			f1 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat g1 = .69f; GLfloat h1 = .4f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(g, h); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			g1 + (radius * cos(i * twicePi / triangleAmount)),
			h1 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	GLfloat e11 = .66f; GLfloat f11 = .44f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e11, f11); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e11 + (radius * cos(i * twicePi / triangleAmount)),
			f11 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();

	GLfloat e12 = .55f; GLfloat f12 = .44f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e12, f12); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e12 + (radius * cos(i * twicePi / triangleAmount)),
			f12 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	glBegin(GL_QUADS);
	glColor3ub(51, 204, 51);
	glVertex2f(0.45f, 0.33f);
	glVertex2f(0.45f, 0.44f);
	glVertex2f(0.65f, 0.44f);
	glVertex2f(0.65f, 0.33f);
	glEnd();

	GLfloat e123 = .5f; GLfloat f123 = .5f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e123, f123); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e123 + (radius * cos(i * twicePi / triangleAmount)),
			f123 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
	GLfloat e1232 = .6f; GLfloat f1232 = .5f;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(51, 204, 51);
	glVertex2f(e1232, f1232); // center of circle
	for (i = 0; i <= triangleAmount; i++) {
		glVertex2f(
			e1232 + (radius * cos(i * twicePi / triangleAmount)),
			f1232 + (radius * sin(i * twicePi / triangleAmount))
		);
	}
	glEnd();
}

void display(void)

{
	glClear(GL_COLOR_BUFFER_BIT);
	grass();
	road();
	sun();
	houses();
	well();
	bird();
	tree();
	glFlush();
}





void init()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1200, 1200);
	glutInitWindowPosition(50, 50);
	glutCreateWindow(argv[0]);
	glutCreateWindow("Village");
	glutDisplayFunc(display);
	init();
	glutMainLoop();

}

